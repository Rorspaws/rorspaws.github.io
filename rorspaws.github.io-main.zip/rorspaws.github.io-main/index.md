---
date: 2025-02-28
---

<html>
  <head>
    <title>something</title>
  </head>
  <p>will a paragraph work?</p>
  <h1>or a header?</h1>
  <img src="https://placecats.com/500/500">
</html>
